<?php
class Passivos extends TRecord
{
    const TABLENAME = 'passivos';
    const PRIMARYKEY= 'id_passivo';
    const IDPOLICY =  'max'; 
    
    /**
     * Constructor method
     * @param $id Primary key to be loaded (optional)
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);

        parent::addAttribute('usuario');
        parent::addAttribute('nome_passivo');
        parent::addAttribute('valor_passivo');
        parent::addAttribute('tempo_passivo');
        
    }
}
