<?php
class Ativos extends TRecord
{
    const TABLENAME = 'ativos';
    const PRIMARYKEY= 'id_ativo';
    const IDPOLICY =  'max'; 
    // const FOREIGNKEY=  'usuario';
    
    /**
     * Constructor method
     * @param $id Primary key to be loaded (optional)
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('usuario');
        parent::addAttribute('nome_ativo');
        parent::addAttribute('valor_ativo');
        parent::addAttribute('tempo_ativo');
        
    }
}
