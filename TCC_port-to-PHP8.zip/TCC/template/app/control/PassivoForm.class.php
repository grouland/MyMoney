<?php
/**
 * PessoaForm Form
 * @author  Rodrigo Warzak
 */
class PassivoForm extends TStandardForm
{
    protected $form; // form

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();
        parent::setDatabase('mymoney');
        parent::setActiveRecord('Passivos');


        // echo '<pre >';
        // print_r($_SESSION);
        // echo '</pre>';
        // creates the form
        $this->form = new BootstrapFormBuilder('form_Passivo');
        $this->form->setFormTitle('Cadastro de Passivos');


        $nome_passivo = new TEntry('nome_passivo');
        $valor_passivo = new TNumeric('valor_passivo', 2, ',', '.', true);
        $tempo_passivo = new TCombo('tempo_passivo');

        $items = [ 30 => '30'];
        $tempo_passivo->addItems($items);


        $tempo_passivo->addValidation('de Dias a Pagar', new TRequiredValidator());
        $nome_passivo->addValidation('Nome', new TRequiredValidator());

        // $usuario->setEditable(false);
        // $usuario->setSize(100);
        // $usuario->setValue('1');

        $nome_passivo->setSize('100%');



        // $this->form->addFields([new TLabel('Id:')],[$usuario]);
        $this->form->addFields([new TLabel('Nome do Passivo:')],[$nome_passivo]);
        $this->form->addFields([new TLabel('Valor do Passivo')],[$valor_passivo]);
        $this->form->addFields([new TLabel('Dias a Pagar')],[$tempo_passivo]);


        // create the form actions
        $this->form->addAction('Salvar', new TAction([$this, 'onSave']), 'fa:floppy-o')->addStyleClass('btn-primary');

        $this->form->addAction('Limpar formulário', new TAction([$this, 'onClear']), 'fa:eraser #dd5a43');

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        //$container->add(new TXMLBreadCrumb('menu.xml', 'CidadeList'));
        $container->add($this->form);


        parent::add($container);
    }

    public function onShow($param = null){

    }

    public function onSave()
    {
        try
        {
            TTransaction::open($this->database);

            $data = $this->form->getData();

            $object = new Passivos;
            $object->usuario = TSession::getValue('userid');
            $object->nome_passivo = $data->nome_passivo;
            $object->valor_passivo = $data->valor_passivo;
            $object->tempo_passivo = $data->tempo_passivo;

            $object->fromArray( (array) $data);

            $this->form->validate();

            $object->store();
            // $data->id = $object->id;
            $this->form->setData($data);

            // $object->clearParts();

            TTransaction::close();

            new TMessage('info', AdiantiCoreTranslator::translate('Record saved'));

            return $object;
        }
        catch (Exception $e) // in case of exception
        {
            // get the form data
            $object = $this->form->getData($this->activeRecord);
            $this->form->setData($object);
            new TMessage('error', $e->getMessage());
            TTransaction::rollback();
        }
    }

}
