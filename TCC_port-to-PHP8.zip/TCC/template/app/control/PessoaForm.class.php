<?php
/**
 * PessoaForm Form
 * @author  Rodrigo Warzak
 */
class PessoaForm extends TStandardForm
{
    protected $form; // form

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();
        parent::setDatabase('projeto1');
        parent::setActiveRecord('pessoa');

        // creates the form
        $this->form = new BootstrapFormBuilder('form_Pessoa');
        $this->form->setFormTitle('Cadastro de Pessoa');


        $id   = new TEntry('id');
        $nome = new TEntry('nome');
        $email = new TEntry('email');
        $salario = new TNumeric('salario', 2, ',', '.', true);
        $foto = new TFile('foto');

        $foto->setAllowedExtensions( ['png', 'jpg'] );
        $data_nascimento = new TDateTime('data_nascimento');
        $data_nascimento->setMask('dd/mm/yyyy hh:ii');
        $data_nascimento->setDatabaseMask('yyyy-mm-dd hh:ii');


        $nome->addValidation('Nome', new TRequiredValidator());

        $id->setEditable(false);
        $id->setSize(100);
        $nome->setSize('100%');



        $this->form->addFields([new TLabel('Id:')],[$id]);
        $this->form->addFields([new TLabel('Nome:')],[$nome]);
        $this->form->addFields([new TLabel('E-mail:')],[$email]);
        $this->form->addFields([new TLabel('Salário:')],[$salario]);
        $this->form->addFields([new TLabel('Foto')],[$foto]);
        $this->form->addFields([new TLabel('Data Nascimento:')],[$data_nascimento]);
        $email->addValidation('E-mail', new TEmailValidator);

        // create the form actions
        $this->form->addAction('Salvar', new TAction([$this, 'onSave']), 'fa:floppy-o')->addStyleClass('btn-primary');

        $this->form->addAction('Limpar formulário', new TAction([$this, 'onClear']), 'fa:eraser #dd5a43');

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        //$container->add(new TXMLBreadCrumb('menu.xml', 'CidadeList'));
        $container->add($this->form);


        parent::add($container);
    }


    public function onShow($param = null){

    }

}
